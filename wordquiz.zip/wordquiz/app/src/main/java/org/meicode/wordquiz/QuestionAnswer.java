package org.meicode.wordquiz;

public class QuestionAnswer {

    public static String question[] = {
            "Which company owns the android?",
            "Which one is not the programming language?",
            "Which you are watching this vedio?"

    };

    public static String choices[][] = {
            {"Google","Apple","Nokia","Samaung"},
            {"Java","Kotlin","Notepad","Python"},
            {"Facebook","Whatsapp","Instagram","Youtube"}

    };

    public static String correctAnswersp[] = {
            "Google",
            "Notepad",
            "Youtube"
    };
}
